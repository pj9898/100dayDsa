//https://practice.geeksforgeeks.org/problems/find-all-factorial-numbers-less-than-or-equal-to-n3548/1?utm_source=geeksforgeeks&utm_medium=ml_article_practice_tab&utm_campaign=article_practice_tab
class Solution{
    static ArrayList<Long> factorialNumbers(long n){
        // code here
        ArrayList<Long> ans= new ArrayList<Long>();
        long i = 1;
        long j = 2;
        while (i <= n)
        {
            ans.add(i);
            i = i * j;
            j++;
        }
       
       return ans;
            
    }
}