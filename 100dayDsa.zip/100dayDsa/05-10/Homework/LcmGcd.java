//https://practice.geeksforgeeks.org/problems/gcd-lcm-and-distributive-property4419/1?utm_source=geeksforgeeks&utm_medium=ml_article_practice_tab&utm_campaign=article_practice_tab


class Solution{
    static long gcd(long a, long b)
    {
        if (b == 0) {
           return a;
        } 
        else{
            return gcd(b, a % b);
        }
            
    }
    static long findValue(int x, int y, int z){
        //complete the function here
        long a=x;
        long b=y;
        long c=z;
        
        long  LcmXY=((a*b)/gcd(a,b));
        long LcmYZ=((a*c)/gcd(a,c));
        long ans=gcd(LcmXY,LcmYZ);
        return  ans;
    }
}